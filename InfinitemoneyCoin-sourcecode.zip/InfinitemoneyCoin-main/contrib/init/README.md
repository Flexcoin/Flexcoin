Sample configuration files for:

SystemD: infinitemoneycoind.service
Upstart: infinitemoneycoind.conf
OpenRC:  infinitemoneycoind.openrc
         infinitemoneycoind.openrcconf
CentOS:  infinitemoneycoind.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
